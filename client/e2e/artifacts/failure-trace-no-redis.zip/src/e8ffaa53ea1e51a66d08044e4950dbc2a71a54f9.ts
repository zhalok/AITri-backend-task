import { expect, test, type Browser, type Page } from '@playwright/test'

/**
 * Two browsers, one meeting: the facilitator advances the agenda and the second browser follows on its own.
 *
 * Fixture and clock: the stack is started from the seeded database with the server clock pinned (APP_NOW in
 * docker-compose.yml), so both browsers see the same business time and the same data. The test never touches the
 * clock. It ends the meeting it started, and ends a meeting left over from an aborted run first, so it can be
 * re-run against the same stack.
 */

const TEAM = 'team_lead'
const FACILITATOR = 'blake@acme.test' // seeded Team Member, member of team_lead
const ATTENDEE = 'casey@acme.test' // seeded Team Member, member of team_lead

async function signedInPage(browser: Browser, email: string): Promise<Page> {
  const context = await browser.newContext() // its own storage: a different person in a different browser
  const page = await context.newPage()
  await page.goto('/')
  await page.getByLabel('Email').fill(email)
  await page.getByRole('button', { name: 'Sign in' }).click()
  await expect(page.getByLabel('Email')).toHaveCount(0) // the sign-in form is gone: we are in
  return page
}

test.beforeAll(async ({ request }) => {
  // A meeting left running by an aborted run would turn "Start meeting" into "Join meeting". Only a meeting's own
  // facilitator can end it, and a run that was aborted was always started by FACILITATOR, so end it as them.
  const login = await request.post('/api/auth/login', { data: { email: FACILITATOR } })
  const headers = { Authorization: `Bearer ${(await login.json()).access_token}` }
  const active = await (await request.get(`/api/teams/${TEAM}/meetings/active`, { headers })).json()
  if (active) {
    const ended = await request.post(`/api/meetings/${active.id}/end`, { headers })
    expect(ended.ok(), 'a meeting not started by this test is running; reset the stack').toBeTruthy()
  }
})

test('the second browser follows when the facilitator advances the agenda', async ({ browser }) => {
  const facilitator = await signedInPage(browser, FACILITATOR)
  const attendee = await signedInPage(browser, ATTENDEE)
  const section = (page: Page) => page.getByTestId('current-section')

  // Blake starts the meeting and lands in the room, on the first agenda section.
  await facilitator.goto(`/teams/${TEAM}/meeting`)
  await facilitator.getByRole('button', { name: 'Start meeting' }).click()
  await expect(facilitator).toHaveURL(/\/meeting\/.+/)
  await expect(section(facilitator)).toHaveText('Scorecard')

  // Casey opens the same team's meeting page, which takes them into the running meeting.
  await attendee.goto(`/teams/${TEAM}/meeting`)
  await expect(attendee).toHaveURL(/\/meeting\/.+/)
  await expect(section(attendee)).toHaveText('Scorecard')
  await expect(attendee.getByRole('button', { name: 'Next section' })).toHaveCount(0) // only the facilitator advances

  // Both see each other as attendees (live presence).
  await expect(facilitator.getByText('Attendees (2)')).toBeVisible()
  await expect(attendee.getByText('Attendees (2)')).toBeVisible()

  // Blake advances. Casey's page changes by itself: no reload, no click.
  await facilitator.getByRole('button', { name: 'Next section' }).click()
  await expect(section(facilitator)).toHaveText('IDS')
  await expect(section(attendee)).toHaveText('IDS')

  // Clean up so the test can run again: the facilitator ends the meeting and the attendee sees it end.
  facilitator.once('dialog', (d) => d.accept())
  await facilitator.getByRole('button', { name: 'End meeting' }).click()
  await expect(section(attendee)).toHaveText('Ended')
})
